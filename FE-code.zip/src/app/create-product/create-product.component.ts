import { Component, OnInit } from '@angular/core';
import { Product } from '../models/product.model';
import { ProductService } from '../services/product.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'; // Import Validators and FormBuilder


@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.css']
})
export class CreateProductComponent implements OnInit {

  productForm!: FormGroup; 
 
  message: string = '';
  flag: boolean = false;
  classMessage: string = '';
 
  constructor(private fb: FormBuilder, private productService: ProductService) {}

  ngOnInit() {
    this.productForm = this.fb.group({
      productName: ['', [Validators.required]],
      sku: ['', [Validators.required]],
      qty: ['', [Validators.required]],
     
    });
  }

  onSubmit() {
    if (this.productForm.valid) {
      // Form is valid, proceed to submit
      const product: Product = this.productForm.value;
      console.log(product)
      // Call the service to insert the complaint data
      this.productService.insertProduct(product).subscribe(
        response => {
          this.flag = true; 
          this.classMessage = 'success'; 
          this.message = response.message; 
          console.log('product submitted successfully', response);
          // Optionally, you can redirect or show a success message here
        },
        error => {
          this.flag = false; 
          this.message = error.message; 
          console.log( this.message);
          this.classMessage = 'error'; 
          console.error('Error submitting product', error);
          // Handle error (show a message or log it)
        }
      );

    } else {
        this.flag = false; 
        this.message = "Please fill all required fields"; 
        console.log( this.message);
        this.classMessage = 'error'; 

        console.log('Form is invalid');
    }
  }





}
