import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  productList : any[] = [];
  pagedProductList: any[] = [];
  pageSize = 2; 
  currentPage = 1;
  constructor(private productService: ProductService, private router: Router) {}


  ngOnInit(): void {

    this.productService.getAllProduct().subscribe(
      response => {
       
          this.productList = response.response; 
          this.setPage(1); 
      
       
      },
      error => {
        console.error('Error while getting product list', error);
      }
    );
  }

  setPage(page: number): void {
    if (page < 1 || page > this.pages.length) {
      return;
    }

    
    const startIndex = (page - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
   
    this.pagedProductList  = this.productList.slice(startIndex, endIndex);
    this.currentPage = page;
  }

  get pages(): number[] {
    
    const pageCount = Math.ceil(this.productList.length / this.pageSize);
    return Array.from({ length: pageCount }, (_, index) => index + 1);
  }
  createProduct(): void {
    this.router.navigate(['/create-product']);
  }

}
