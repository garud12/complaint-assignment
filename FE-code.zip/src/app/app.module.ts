import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule, } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ComplaintListComponent } from './complaint-list/complaint-list.component';
import { ComplaintCreateComponent } from './complaint-create/complaint-create.component';
import { ProductService } from './services/product.service';
import { ComplaintService } from './services/complaint.service';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { CreateProductComponent } from './create-product/create-product.component';

const routes: Routes = [
  { path: 'complaint-list', component: ComplaintListComponent },
  { path: 'complaint-create', component: ComplaintCreateComponent },
  { path: 'product-list', component: ProductListComponent },
  { path: 'create-product', component: CreateProductComponent },
  { path: '', redirectTo: '/complaint-list', pathMatch: 'full' },
];

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ComplaintListComponent,
    ComplaintCreateComponent,
    CreateProductComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    [RouterModule.forRoot(routes)],
  ],
  providers: [ProductService, ComplaintService],
  bootstrap: [AppComponent]
})
export class AppModule {
 
 }
