import { Component, OnInit } from '@angular/core';
import { ComplaintService } from '../services/complaint.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-complaint-list',
  templateUrl: './complaint-list.component.html',
  styleUrls: ['./complaint-list.component.css']
})
export class ComplaintListComponent implements OnInit {
  complaintList : any[] = [];
  pagedComplaintList: any[] = [];
  pageSize = 2; 
  currentPage = 1;
  constructor(private complaintService: ComplaintService, private router: Router) {}


  ngOnInit(): void {

    this.complaintService.getAllComplaint().subscribe(
      response => {
       
          this.complaintList = response.response; 
          this.setPage(1); 
        console.log('Complaint submitted successfully', response);
       
      },
      error => {
        console.error('Error submitting complaint', error);
      }
    );
  }

  setPage(page: number): void {
    if (page < 1 || page > this.pages.length) {
      return;
    }

    
    const startIndex = (page - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
   
    this.pagedComplaintList  = this.complaintList.slice(startIndex, endIndex);
    this.currentPage = page;
  }

  get pages(): number[] {
    
    const pageCount = Math.ceil(this.complaintList.length / this.pageSize);
    return Array.from({ length: pageCount }, (_, index) => index + 1);
  }

  createComplaint(): void {
    this.router.navigate(['/complaint-create']);
  }

}
