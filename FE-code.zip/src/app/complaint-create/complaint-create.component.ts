import { Component, OnInit } from '@angular/core';
import { Complaint } from '../models/complaint.model';
import { ComplaintService } from '../services/complaint.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'; // Import Validators and FormBuilder
import { ProductService } from '../services/product.service';


@Component({
  selector: 'app-complaint-create',
  templateUrl: './complaint-create.component.html',
  styleUrls: ['./complaint-create.component.css']
})
export class ComplaintCreateComponent implements OnInit {

  complaintForm!: FormGroup; 
  message: string = '';
  flag: boolean = false;
  classMessage: string = '';
  productList : any[] = []; 
 
  constructor(private fb: FormBuilder,private productService: ProductService, private complaintService: ComplaintService) {
    

    
    this.productService.getAllProduct().subscribe(
      response => {
       
          this.productList = response.response; 
          
      
       
      },
      error => {
        console.error('Error while getting product list', error);
      }
    );

  
  }

  ngOnInit() {
    this.complaintForm = this.fb.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      productName: ['', [Validators.required]],
      complaint: ['', [Validators.required]],
    });
  }

  onSubmit() {
    if (this.complaintForm.valid) {
      // Form is valid, proceed to submit
      const complaint: Complaint = this.complaintForm.value;
      console.log(complaint)
      // Call the service to insert the complaint data
      this.complaintService.insertComplaint(complaint).subscribe(
        response => {
          this.flag = true; 
          this.classMessage = 'success'; 
          this.message = response.message; 
          console.log('Complaint submitted successfully', response);
          // Optionally, you can redirect or show a success message here
        },
        error => {
          this.flag = false; 
          this.message = error.message; 
          console.log( this.message);
          this.classMessage = 'error'; 
          console.error('Error submitting complaint', error);
          // Handle error (show a message or log it)
        }
      );

    } else {
        this.flag = false; 
        this.message = "Please fill all required fields"; 
        console.log( this.message);
        this.classMessage = 'error'; 

        console.log('Form is invalid');
    }
  }





}
