export class Complaint {
    constructor(
      public name: string,
      public email: string,
      public productName: string,
      public complaint: string
    ) {}
  }