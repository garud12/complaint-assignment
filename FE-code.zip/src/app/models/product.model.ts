export class Product {
    constructor(
      public productName: string,
      public sku: string,
      public qty: string,
    ) {}
  }