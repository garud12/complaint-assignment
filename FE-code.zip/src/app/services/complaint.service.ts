import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Complaint } from '../models/complaint.model';

const headers = new HttpHeaders({
  'Content-Type': 'application/json',
  // Add any other headers as needed
});

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {
  private apiUrl = 'http://localhost:3000';
  constructor(private http: HttpClient) {}
 
  insertComplaint(complaint: Complaint): Observable<any> {
    return this.http.post(`${this.apiUrl}/createComplaint`, complaint, { headers });
  }

  getAllComplaint(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getAllComplaints`,  { headers });
  }

}
