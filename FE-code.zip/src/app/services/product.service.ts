import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../models/product.model';

const headers = new HttpHeaders({
  'Content-Type': 'application/json',
  // Add any other headers as needed
});

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'http://localhost:3000';
  constructor(private http: HttpClient) {}

  insertProduct(product: Product): Observable<any> {
    return this.http.post(`${this.apiUrl}/createProduct`, product, { headers });
  }

  getAllProduct(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getAllProducts`,  { headers });
  }

}
