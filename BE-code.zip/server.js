const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
const port = 3000;

// Use bodyParser for parsing JSON
app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB (adjust the connection string accordingly)
mongoose.connect('mongodb://127.0.0.1:27017/est', { useNewUrlParser: true, useUnifiedTopology: true });

// Define a mongoose schema for the complaint
const complaintSchema = new mongoose.Schema({
  name: String,
  email: String,
  productName: String,
  complaint: String,
});

const productSchema = new mongoose.Schema({
  productName: String,
  sku: String,
  qty: Number,
  date: Date,
});


// Create a mongoose model for the complaint
const Complaint = mongoose.model('Complaint', complaintSchema);
const Product = mongoose.model('Product', productSchema);

// Define the route for handling POST requests
app.post('/createComplaint', async (req, res) => {
  try {
    // Create a new instance of the Complaint model with the data from the request body
    const newComplaint = new Complaint({
      name: req.body.name,
      email: req.body.email,
      productName: req.body.productName,
      complaint: req.body.complaint,
     
      // Map other fields accordingly
    });

    // Save the new complaint to the database
    const savedComplaint = await newComplaint.save();

    console.log('Complaint saved to MongoDB:', savedComplaint);

    res.json({ response: savedComplaint, message: 'We have received your complaint.' });
  } catch (error) {
    console.error('Error saving complaint to MongoDB:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Define the route for handling POST requests
app.post('/createProduct', async (req, res) => {
  try {
    // Create a new instance of the Complaint model with the data from the request body
    const newProduct = new Product({
      productName: req.body.productName,
      sku: req.body.sku,
      qty: req.body.qty,
      date:  Date(),
    });

    // Save the new product to the database
    const savedProduct = await newProduct.save();

    console.log('savedProduct saved to MongoDB:', savedProduct);

    res.json({ response: savedProduct, message: 'Product saved successfully.' });
  } catch (error) {
    console.error('Error saving complaint to MongoDB:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Define the route for getting all products
app.get('/getAllProducts', async (req, res) => {
  try {
    // Retrieve all products from the database
    const allProducts = await Product.find();

    res.json({ response: allProducts, message: 'All products retrieved successfully.' });
  } catch (error) {
    console.error('Error retrieving products from MongoDB:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});



// Define the route for getting all products
app.get('/getAllComplaints', async (req, res) => {
  try {

    const allCompaints = await Complaint.find();
    res.json({ response: allCompaints, message: 'All complaints retrieved successfully.' });
  } catch (error) {
    console.error('Error retrieving products from MongoDB:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});


